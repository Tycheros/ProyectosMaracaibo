<?php
// backend/fix-password.php
// Herramienta de desarrollo para restaurar la contraseña del usuario demo (solo localhost)
header('Content-Type: text/html; charset=utf-8');

// Restringir acceso fuera de localhost
$remote = $_SERVER['REMOTE_ADDR'] ?? '';
if ($remote !== '127.0.0.1' && $remote !== '::1') {
    echo "<p>Acceso restringido. Ejecutar desde el servidor local (localhost).</p>";
    exit;
}

require __DIR__ . '/config.php';

echo "<h2>🔧 Fix Password Tool (dev)</h2>";

$email = 'demo@tesis.com';

try {
    $stmt = $pdo->prepare('SELECT id_usuario, email, nombre, rol, estado, password_hash FROM usuarios WHERE email = ?');
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if (!$user) {
        echo "<p style='color: orange;'>Usuario demo no encontrado. Creando usuario...</p>";
        $hash = password_hash('123456', PASSWORD_DEFAULT);
        $stmt = $pdo->prepare('INSERT INTO usuarios (nombre, email, password_hash, rol, estado) VALUES (?, ?, ?, ?, ?)');
        if ($stmt->execute(['Usuario Demo', $email, $hash, 'usuario', 'activo'])) {
            echo "<p style='color: green;'>Usuario demo creado con contraseña '123456'.</p>";
        } else {
            echo "<p style='color: red;'>Error al crear el usuario demo.</p>";
        }
        exit;
    }

    echo "<p>Usuario encontrado: <strong>" . htmlspecialchars($user['email']) . "</strong> (ID: " . intval($user['id_usuario']) . ")</p>";

    if (isset($_GET['fix'])) {
        $newHash = password_hash('123456', PASSWORD_DEFAULT);
        $stmt = $pdo->prepare('UPDATE usuarios SET password_hash = ? WHERE email = ?');
        if ($stmt->execute([$newHash, $email])) {
            echo "<p style='color: green;'>Contraseña actualizada a '123456'.</p>";
        } else {
            echo "<p style='color: red;'>No se pudo actualizar la contraseña.</p>";
        }
    } else {
        echo "<p><a href='?fix=1' style='background: #4CAF50; color: white; padding: 8px 12px; text-decoration: none; border-radius: 4px;'>🔧 Restaurar contraseña a '123456'</a></p>";
    }

} catch (PDOException $e) {
    echo "<p style='color: red;'>Error de base de datos: " . htmlspecialchars($e->getMessage()) . "</p>";
}

echo "<p><a href='../test-local.html'>↩️ Volver al test de login</a></p>";
