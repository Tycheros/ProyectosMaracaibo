<?php
// backend/config.php
ini_set('display_errors', 0); // Desactivamos errores de texto para no ensuciar el JSON
error_reporting(0);

$host = 'sql110.infinityfree.com';
$db   = 'if0_41183042_bd_proyectos';
$user = 'if0_41183042';
$pass = 'oc70gHwJlzhGs'; 
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    header('Content-Type: application/json');
    echo json_encode(['ok' => false, 'msg' => 'Error de conexión']);
    exit;
}