<?php
// backend/test-login-cli.php
// Script de diagnóstico: verificar conexión a BD y verificación de contraseña.
header('Content-Type: application/json; charset=utf-8');

require __DIR__ . '/config.php';

$email = '';
$password = '';

// CLI: php test-login-cli.php email password
if (PHP_SAPI === 'cli') {
    global $argv;
    $email = $argv[1] ?? '';
    $password = $argv[2] ?? '';
} else {
    $email = $_GET['email'] ?? '';
    $password = $_GET['password'] ?? '';
}

if (!$email) {
    echo json_encode(['ok' => false, 'msg' => 'Email requerido', 'usage' => 'php backend/test-login-cli.php email password OR /backend/test-login-cli.php?email=...&password=...']);
    exit;
}

try {
    $stmt = $pdo->prepare('SELECT id_usuario, email, nombre, rol, estado, password_hash FROM usuarios WHERE email = ?');
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if (!$user) {
        echo json_encode(['ok' => false, 'msg' => 'Usuario no encontrado', 'email' => $email]);
        exit;
    }

    $stored = $user['password_hash'] ?? '';
    $verified = $stored ? password_verify($password, $stored) : false;

    echo json_encode([
        'ok' => true,
        'email' => $user['email'],
        'id' => $user['id_usuario'],
        'nombre' => $user['nombre'] ?? null,
        'estado' => $user['estado'] ?? null,
        'stored_hash_prefix' => substr($stored, 0, 10),
        'password_provided' => ($password !== ''),
        'verified' => $verified
    ]);

} catch (PDOException $e) {
    echo json_encode(['ok' => false, 'msg' => 'Error DB', 'error' => $e->getMessage()]);
}

?>